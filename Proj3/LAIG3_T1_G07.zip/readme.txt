Turma 1 Grupo 7
Ant�nio Ramadas up201303568
Rui Vilares up201207046